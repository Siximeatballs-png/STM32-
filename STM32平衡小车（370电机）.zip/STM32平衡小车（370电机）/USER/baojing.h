#ifndef __BAOJING_H
#define _BAOJING_H
void baojing_Init(void);
#endif
